module.exports = [

	'./gulp/tasks/pug',
	'./gulp/tasks/serv',
	'./gulp/tasks/watch',
	'./gulp/tasks/sass',
	'./gulp/tasks/script',
	'./gulp/tasks/svg',
	'./gulp/tasks/file',
	'./gulp/tasks/copylibs',
	// './gulp/tasks/cleanimg',
	'./gulp/tasks/img-responsive',
	// './gulp/tasks/font',
];